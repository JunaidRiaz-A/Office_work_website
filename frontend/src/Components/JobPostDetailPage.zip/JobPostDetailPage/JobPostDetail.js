import React, { useEffect, useRef, useState } from "react";
import "./../JobPostDetailPage/JobPostDetailPage.css";
import Navbarsynergtech from "../Homepage/Navbarsynergtech/Navbarsynergtech";
import FooterAll from "../Homepage/FooterAll/FooterAll";
import Footer from "../Homepage/Footer/Footer";
import { CiLocationOn } from "react-icons/ci";
import { CiDollar } from "react-icons/ci";
import arrow from "./../../Assets/arrow_blue.png";
import { FaFacebookF } from "react-icons/fa";
import { FaPinterest } from "react-icons/fa6";
import category from "./../../Assets/category_over.png";
import date from "./../../Assets/date_over.png";
import location from "./../../Assets/location_over.png";
import salary from "./../../Assets/salary_over.png";
import Experience from "./../../Assets/exp_over.png";
import gender from "./../../Assets/gender_over.png";
import qualification from "./../../Assets/qualitfication_over.png";
import arrow_send_mesg from "./../../Assets/send_mesg_over.png";
import axios from "axios";
import synergy from "./../../Assets/synergy-logo-3 1.png";
import clock from "./../../Assets/clock_syn.png";
import { useLocation } from "react-router-dom";
import phone from "./../../Assets/phone_syn.png";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {
  FaFacebook,
  FaTwitter,
  FaInstagram,
  FaLinkedin,
  FaYoutube,
} from "react-icons/fa";
import { Link } from "react-router-dom";
import { IoReorderThreeOutline } from "react-icons/io5";
import Appointment from "../Homepage/Appointment/Appointment";
function JobPostDetail() {
  // State to store form values
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    resume: null,
  });

  // Handle input change
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  // Handle file input change
  const handleFileChange = (e) => {
    setFormData({
      ...formData,
      resume: e.target.files[0], // Store the file
    });
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
  
    console.log("Form Data Before Submit:", formData); // Debug log
  
    // Create a FormData object to handle the file upload
    const formToSubmit = new FormData();
    formToSubmit.append("name", formData.name);
    formToSubmit.append("email", formData.email);
    formToSubmit.append("phone", formData.phone);
    formToSubmit.append("resume", formData.resume);
  
    try {
      const response = await axios.post("http://localhost:8000/api/apply-job", formToSubmit, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });
  
      if (response) {
        alert("Application submitted successfully!");
        setFormData({
          name: '',
          email: '',
          phone: '',
          resume: '',
        });
      }
    } catch (error) {
      console.error("Error submitting the form", error);
      alert("Failed to submit the form");
    }
  };

  const appointmentRef = useRef(null);

  const scrollToAppointment = () => {
    if (appointmentRef.current) {
      appointmentRef.current.scrollIntoView({ behavior: "smooth" });
    }
  };

  const [isVisible, setIsVisible] = useState(false);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener("scroll", toggleVisibility);
    scrollToTop();
    return () => {
      window.removeEventListener("scroll", toggleVisibility);
    };
  }, []);

  const location = useLocation();
  const { jobId } = location.state; // Get jobId from the state
  const [job, setJob] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchJobDetails = async () => {
      try {
        const response = await fetch(`http://localhost:8000/api/jobs/${jobId}`);
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const data = await response.json();
        setJob(data);
      } catch (error) {
        console.error("Failed to fetch job details:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchJobDetails();
  }, [jobId]);

  if (loading) return <p>Loading job details...</p>;
  if (!job) return <p>Job not found.</p>;

  return (
    <div>
      <>
        {isVisible && (
          <button onClick={scrollToTop} className="scroll-to-top-button">
            <span>&uarr;</span>
          </button>
        )}
      </>
      <>
        <div className="main_div_sticky">
          <>
            <div className="uppernavbar">
              <div className="inside_div_navbar">
                <div className="d-flex justify-content-between content-wrapper">
                  <div className="d-flex flex-row">
                    <div className="d-flex flex-row">
                      <img
                        src={clock}
                        className="clock_style_syn"
                        alt="clock"
                      />
                      <p className="clock_para_syn">
                        Mon - Fri: 09.00am - 10.00 pm
                      </p>
                    </div>
                    <div className="d-flex flex-row main_div_clock">
                      <img
                        src={clock}
                        className="clock_style_syn"
                        alt="clock"
                      />
                      <p className="clock_para_syn">
                        Richardson, California 62639
                      </p>
                    </div>
                    <div className="d-flex flex-row main_div_clock">
                      <img
                        src={clock}
                        className="clock_style_syn"
                        alt="clock"
                      />
                      <p className="clock_para_syn">TANGO@mail.com</p>
                    </div>
                  </div>

                  <div className="transform_second_div">
                    <div className="d-flex flex-row">
                      <div className="d-flex flex-row">
                        <img
                          src={phone}
                          className="phone_style_syn"
                          alt="phone"
                        />
                        <p className="clock_para_syn">Make a Call</p>
                        <p className="phone_p7ara_syn_bold">+36 55 540 069</p>
                        <div className="social-media-row">
                          <a
                            href="https://www.facebook.com"
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <FaFacebook className="social-icon" />
                          </a>
                          <a
                            href="https://www.twitter.com"
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <FaTwitter className="social-icon" />
                          </a>
                          <a
                            href="https://www.instagram.com"
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <FaInstagram className="social-icon" />
                          </a>
                          <a
                            href="https://www.linkedin.com"
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <FaLinkedin className="social-icon" />
                          </a>
                          <a
                            href="https://www.youtube.com"
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <FaYoutube className="social-icon" />
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
          <nav class="navbar navbar-expand-lg p-0 m-0">
            <a class="navbar-brand">
              <Link to="/">
                <img src={synergy} className="synergytech_logo" />
              </Link>
            </a>
            <button
              class="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <IoReorderThreeOutline />
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                  <Link to="/">
                    <p class="navitems_synergytechnavbar1">HOME </p>
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/aboutus">
                    <p class="navitems_synergytechnavbar">ABOUS US</p>
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/blogs">
                    <p class="navitems_synergytechnavbar">BLOGS </p>
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/applynow">
                    <p class="navitems_synergytechnavbar">APPLY NOW</p>
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/team">
                    <p class="navitems_synergytechnavbar">TEAM </p>
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/portfolio">
                    <p class="navitems_synergytechnavbar">PORTFOLIO </p>
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/case/studies">
                    <p class="navitems_synergytechnavbar">CASE STUDY</p>
                  </Link>
                </li>
              </ul>
              <form class="form-inline">
                <button
                  className="btn_request_quote"
                  type="button"
                  onClick={scrollToAppointment}
                >
                  REQUEST A QUOTE
                </button>
              </form>
            </div>
          </nav>
        </div>
      </>
      <>
        <div className="main_div_designation">
          <div className="row m-0 p-0">
            <div className="col-lg-2 col-md-1 col-sm-12 col-12"></div>
            <div className="col-lg-8 col-md-9 col-sm-12 col-12">
              <div className="row p-0 m-0 ">
                <div className="col-lg-8 col-md-12 col-sm-12 col-12">
                  <div className="main_description_designation">
                    <p className="header_designation">{job.title}</p>
                    <div className="d-flex flex-row">
                      <p className="by_description">By</p>
                      <p className="Spotify_description">Spotify</p>
                      <p className="by_description">in</p>
                      <p className="Design_Creative_description">
                        {job.category}
                      </p>
                    </div>
                    <div className="d-flex flex-row">
                      <button className="btn_in_house">{job.mode}</button>
                      <button className="btn_in_house">
                        {" "}
                        <CiLocationOn /> {job.location}
                      </button>
                      <button className="btn_in_house">
                        <CiDollar /> {job.salary}
                      </button>
                    </div>
                    <hr className="hr_line_below_header" />
                    <p className="description_heading">Description</p>
                    <p className="description_para_designation">
                      {job.description}
                    </p>

                    <p className="description_heading">Requirements</p>
                    <p className="description_para_designation">
                      {job.requirements}
                    </p>

                    <div className="d-flex flex-row">
                      <img className="blue_arrow" src={arrow} />
                      <p className="blue_Arrow_para">
                        Be involved in every step of the product design cycle
                        from discovery to developer handoff and user acceptance
                        testing.
                      </p>
                    </div>
                    <div className="d-flex flex-row">
                      <img className="blue_arrow" src={arrow} />
                      <p className="blue_Arrow_para">
                        Be involved in every step of the product design cycle
                        from discovery to developer handoff and user acceptance
                        testing.
                      </p>
                    </div>
                    <div className="d-flex flex-row">
                      <img className="blue_arrow" src={arrow} />
                      <p className="blue_Arrow_para">
                        Be involved in every step of the product design cycle
                        from discovery to developer handoff and user acceptance
                        testing.
                      </p>
                    </div>
                    <div className="d-flex flex-row">
                      <img className="blue_arrow" src={arrow} />
                      <p className="blue_Arrow_para">
                        Be involved in every step of the product design cycle
                        from discovery to developer handoff and user acceptance
                        testing.
                      </p>
                    </div>
                    <div className="d-flex flex-row">
                      <img className="blue_arrow" src={arrow} />
                      <p className="blue_Arrow_para">
                        Be involved in every step of the product design cycle
                        from discovery to developer handoff and user acceptance
                        testing.
                      </p>
                    </div>
                    <div className="d-flex flex-row">
                      <img className="blue_arrow" src={arrow} />
                      <p className="blue_Arrow_para">
                        Be involved in every step of the product design cycle
                        from discovery to developer handoff and user acceptance
                        testing.
                      </p>
                    </div>
                    <div className="d-flex flex-row">
                      <img className="blue_arrow" src={arrow} />
                      <p className="blue_Arrow_para">
                        Be involved in every step of the product design cycle
                        from discovery to developer handoff and user acceptance
                        testing.
                      </p>
                    </div>

                    <p className="description_heading">Skill & Experience</p>
                    <p className="description_para_designation">
                      Et harum quidem rerum facilis est et expedita distinctio.
                      Nam libero tempore c soluta nobisec eligendi optio cumque
                      nihil impedit minus id quod maxime placeat facere possimus
                    </p>

                    <div className="d-flex flex-row">
                      <img className="blue_arrow" src={arrow} />
                      <p className="blue_Arrow_para">
                        Be involved in every step of the product design cycle
                        from discovery to developer handoff and user acceptance
                        testing.
                      </p>
                    </div>
                    <div className="d-flex flex-row">
                      <img className="blue_arrow" src={arrow} />
                      <p className="blue_Arrow_para">
                        Be involved in every step of the product design cycle
                        from discovery to developer handoff and user acceptance
                        testing.
                      </p>
                    </div>
                    <div className="d-flex flex-row">
                      <img className="blue_arrow" src={arrow} />
                      <p className="blue_Arrow_para">
                        Be involved in every step of the product design cycle
                        from discovery to developer handoff and user acceptance
                        testing.
                      </p>
                    </div>
                    <div className="d-flex flex-row">
                      <img className="blue_arrow" src={arrow} />
                      <p className="blue_Arrow_para">
                        Be involved in every step of the product design cycle
                        from discovery to developer handoff and user acceptance
                        testing.
                      </p>
                    </div>
                    <div className="d-flex flex-row">
                      <p className="share_job_post_para">Share job Post:</p>
                      <button className="btn_facebook_post">
                        <FaFacebookF /> Facebook
                      </button>
                      <button className="btn_Twitter_post">
                        <FaTwitter /> Twitter
                      </button>
                      <button className="btn_Pinterest_post">
                        <FaPinterest /> Pinterest
                      </button>
                    </div>

                    <hr className="hr_below_social_media" />

                    <p className="description_heading">Similar Jobs</p>

                    <div className="card_div_jobs">
                      <div className="row m-0 p-0">
                        <div className="col-lg-8 col-md-9 col-sm-9 col-12 ">
                          <p className="title_card_jobs">
                            Senior UI/UX Designer
                          </p>
                          <div className="d-flex flex-row">
                            <p className="by_description">By</p>
                            <p className="Spotify_description">Spotify</p>
                            <p className="by_description">in</p>
                            <p className="Design_Creative_description_orange">
                              Design & Creative
                            </p>
                          </div>
                          <div className="d-flex flex-row">
                            <button className="btn_in_house_orange">
                              In House
                            </button>
                            <button className="btn_in_house_orange">
                              <CiLocationOn /> New York
                            </button>
                            <button className="btn_in_house_orange">
                              <CiDollar /> 45k-60k Yearly
                            </button>
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-3 col-sm-3 col-12">
                          <button className="btn_aply_now">Apply Now</button>
                        </div>
                      </div>
                    </div>
                    <div className="card_div_jobs">
                      <div className="row m-0 p-0">
                        <div className="col-lg-8 col-md-9 col-sm-9 col-12 ">
                          <p className="title_card_jobs">
                            Senior UI/UX Designer
                          </p>
                          <div className="d-flex flex-row">
                            <p className="by_description">By</p>
                            <p className="Spotify_description">Spotify</p>
                            <p className="by_description">in</p>
                            <p className="Design_Creative_description_orange">
                              Design & Creative
                            </p>
                          </div>
                          <div className="d-flex flex-row">
                            <button className="btn_in_house_orange">
                              In House
                            </button>
                            <button className="btn_in_house_orange">
                              {" "}
                              <CiLocationOn /> New York
                            </button>
                            <button className="btn_in_house_orange">
                              <CiDollar /> 45k-60k Yearly
                            </button>
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-3 col-sm-3 col-12">
                          <button className="btn_aply_now">apply Now</button>
                        </div>
                      </div>
                    </div>
                    <div className="card_div_jobs">
                      <div className="row m-0 p-0">
                        <div className="col-lg-8 col-md-9 col-sm-9 col-12 ">
                          <p className="title_card_jobs">
                            Senior UI/UX Designer
                          </p>
                          <div className="d-flex flex-row">
                            <p className="by_description">By</p>
                            <p className="Spotify_description">Spotify</p>
                            <p className="by_description">in</p>
                            <p className="Design_Creative_description_orange">
                              Design & Creative
                            </p>
                          </div>
                          <div className="d-flex flex-row">
                            <button className="btn_in_house_orange">
                              In House
                            </button>
                            <button className="btn_in_house_orange">
                              {" "}
                              <CiLocationOn /> New York
                            </button>
                            <button className="btn_in_house_orange">
                              <CiDollar /> 45k-60k Yearly
                            </button>
                          </div>
                        </div>
                        <div className="col-lg-4 col-md-3 col-sm-3 col-12">
                          <button className="btn_aply_now">apply Now</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="col-lg-4 col-md-12 col-sm-12 col-12 px-2">
                  <div className="hr_blue_second_div" />
                  <p className="heading_interested_injob">
                    Interested in this job?
                  </p>
                  <p className="para_interested">
                    Application deadline has expired
                  </p>
                  <div className="d-flex justify-content-between">
                    <button
                      className="apply_now_interested"
                      data-toggle="modal"
                      data-target="#exampleModal"
                    >
                      Apply Now
                    </button>
                    <div
                      class="modal fade"
                      id="exampleModal"
                      tabindex="-1"
                      role="dialog"
                      aria-labelledby="exampleModalLabel"
                      aria-hidden="true"
                    >
                      <div class="modal-dialog" role="document">
                        <div class="modal-content">
                          {/* <div class="modal-header">
                            <button
                              type="button"
                              class="close"
                              data-dismiss="modal"
                              aria-label="Close"
                            >
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div> */}
                          <div className="modal-body">
                          <p className="apply_job_heading_modal">Apply for Job</p>
                          <p className="apply_job_para_modal">Kindly fill the information</p>

                          <input
                            name="name"
                            className="input_model_job_apply"
                            placeholder="Name"
                            value={formData.name}
                            onChange={handleInputChange}
                          />
                          <input
                            name="email"
                            className="input_model_job_apply"
                            placeholder="E-Mail"
                            value={formData.email}
                            onChange={handleInputChange}
                          />
                          <input
                            name="phone"
                            className="input_model_job_apply"
                            placeholder="Phone Number"
                            value={formData.phone}
                            onChange={handleInputChange}
                          />
                          <input
                            type="file"
                            className="input_model_job_applyupload"
                            onChange={handleFileChange}
                          />
                          <button
                            type="button" // Ensure it's not submitting a form by default
                            className="submit_apply_job_model"
                            onClick={handleSubmit}
                          >
                            Submit
                          </button>
                          <ToastContainer /> {/* This will render the toast notifications */}
                        </div>
                          {/* <div class="modal-footer">
                            <button className="submit_apply_job_model">Submit</button>
                          </div> */}
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="hr_line_below_aply_now" />
                  <div className="over_view_main">
                    <p className="over_view_heading">Overview</p>

                    <div className="row m-0 p-0">
                      <div className="col-lg-2 col-md-2 col-sm-2 col-2">
                        <img className="icon_overview" src={category} />
                      </div>
                      <div className="col-lg-10 col-md-10 col-sm-10 col-10">
                        <p className="heading_overview_para">Categories</p>
                        <p className="para_overview_para">
                          Design & Creative, UI/UX Desinger
                        </p>
                      </div>
                    </div>

                    <div className="row m-0 p-0">
                      <div className="col-lg-2 col-md-2 col-sm-2 col-2">
                        <img className="icon_overview" src={date} />
                      </div>
                      <div className="col-lg-10 col-md-10 col-sm-10 col-10">
                        <p className="heading_overview_para">Date Posted</p>
                        <p className="para_overview_para">April 5, 2023</p>
                      </div>
                    </div>

                    <div className="row m-0 p-0">
                      <div className="col-lg-2 col-md-2 col-sm-2 col-2">
                        <img className="icon_overview" src={location} />
                      </div>
                      <div className="col-lg-10 col-md-10 col-sm-10 col-10">
                        <p className="heading_overview_para">Location</p>
                        <p className="para_overview_para">
                          55 Main Street, Yonkers, New York, USA
                        </p>
                      </div>
                    </div>

                    <div className="row m-0 p-0">
                      <div className="col-lg-2 col-md-2 col-sm-2 col-2">
                        <img className="icon_overview" src={salary} />
                      </div>
                      <div className="col-lg-10 col-md-10 col-sm-10 col-10">
                        <p className="heading_overview_para">Offered Salary</p>
                        <p className="para_overview_para">45k-60k Yearly</p>
                      </div>
                    </div>

                    <div className="row m-0 p-0">
                      <div className="col-lg-2 col-md-2 col-sm-2 col-2">
                        <img className="icon_overview" src={date} />
                      </div>
                      <div className="col-lg-10 col-md-10 col-sm-10 col-10">
                        <p className="heading_overview_para">Expiration date</p>
                        <p className="para_overview_para">June 13, 2024</p>
                      </div>
                    </div>

                    <div className="row m-0 p-0">
                      <div className="col-lg-2 col-md-2 col-sm-2 col-2">
                        <img className="icon_overview" src={Experience} />
                      </div>
                      <div className="col-lg-10 col-md-10 col-sm-10 col-10">
                        <p className="heading_overview_para">Experience</p>
                        <p className="para_overview_para">4+ Years</p>
                      </div>
                    </div>

                    <div className="row m-0 p-0">
                      <div className="col-lg-2 col-md-2 col-sm-2 col-2">
                        <img className="icon_overview" src={gender} />
                      </div>
                      <div className="col-lg-10 col-md-10 col-sm-10 col-10">
                        <p className="heading_overview_para">Gender</p>
                        <p className="para_overview_para">Both</p>
                      </div>
                    </div>
                    <div className="row m-0 p-0">
                      <div className="col-lg-2 col-md-2 col-sm-2 col-2">
                        <img className="icon_overview" src={qualification} />
                      </div>
                      <div className="col-lg-10 col-md-10 col-sm-10 col-10">
                        <p className="heading_overview_para">Qualification</p>
                        <p className="para_overview_para">Bachelor Degree</p>
                      </div>
                    </div>

                    <button className="send_us_btn">
                      Send us message <img src={arrow_send_mesg} />
                    </button>

                    <div className="d-flex justify-content-center">
                      <div className="d-flex flex-row">
                        <button className="btn_social_media_links">
                          <FaTwitter />
                        </button>
                        <button className="btn_social_media_links">
                          <FaFacebook />
                        </button>
                        <button className="btn_social_media_links">
                          <FaInstagram />
                        </button>
                        <button className="btn_social_media_links">
                          <FaPinterest />
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="col-lg-2 col-md-1 col-sm-12 col-12"></div>
          </div>
        </div>
      </>

      <div ref={appointmentRef}>
        <Appointment />
      </div>
      <FooterAll />
      <Footer />
    </div>
  );
}

export default JobPostDetail;

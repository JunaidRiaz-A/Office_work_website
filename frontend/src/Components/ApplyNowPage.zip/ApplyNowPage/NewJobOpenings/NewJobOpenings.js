// import React from "react";
// import "./../NewJobOpenings/NewJobOpenings.css";
// import { CiLocationOn } from "react-icons/ci";
// import { CiDollar } from "react-icons/ci";
// import { useNavigate } from "react-router-dom";

// function NewJobOpenings() {
//   const navigate = useNavigate();

//   const jobDescription = () => {
//     navigate("/job/description");
//   }
//   return (
//     <div className="main_div_newjobopenings">
//       <p className="new_opening_para">New Openings</p>
//       <p className="new_opening_heading">Explore Popular Jobs</p>
//       <div className="d-flex justify-content-center">
//         <div className="new_opening_div_hr"></div>
//       </div>

//       <div className="row m-0 p-0">
//         <div className="col-lg-2 col-md-1 col-sm-12 col-12"></div>
//         <div className="col-lg-8 col-md-10 col-sm-12 col-12">
//           <div className="row">
           
//             <div className="col-lg-6 col-md-6 col-sm-12 col-12">
//               <div className="main_div_job_open_card">
//                 <div className="row p-0 m-0">
//                   <div className="col-lg-8 col-md-9 col-sm-12 col-12">
//                     <p className="heading_position_name">
//                       Senior UI/UX Designer
//                     </p>
//                     <div className="d-flex flex-row">
//                       <p className="by_grey_job_desp">By </p>
//                       <p className="black_para_job_desp">Spotify</p>
//                       <p className="by_grey_job_desp">in</p>
//                       <p className="by_orange_job_desp">Design & Creative</p>
//                     </div>

//                     <div className="d-flex flex-wrap">
//                       <button className="btn_in_house_job">In House</button>
//                       <button className="btn_in_house_job">
//                         <CiLocationOn />
//                         New York
//                       </button>
//                       <button className="btn_in_house_job">
//                         <CiDollar />
//                         45k-60k Yearly
//                       </button>
//                     </div>
//                   </div>
//                   <div className="col-lg-4 col-md-3 col-sm-12 col-12">
//                     <button className="apply_now_btn_job" onClick={jobDescription}>apply Now</button>
//                   </div>
//                 </div>
//               </div>
//             </div>

//             <div className="col-lg-6 col-md-6 col-sm-12 col-12">
//               <div className="main_div_job_open_card">
//                 <div className="row p-0 m-0">
//                   <div className="col-lg-8 col-md-9 col-sm-12 col-12">
//                     <p className="heading_position_name">
//                       Senior UI/UX Designer
//                     </p>
//                     <div className="d-flex flex-row">
//                       <p className="by_grey_job_desp">By </p>
//                       <p className="black_para_job_desp">Spotify</p>
//                       <p className="by_grey_job_desp">in</p>
//                       <p className="by_orange_job_desp">Design & Creative</p>
//                     </div>

//                     <div className="d-flex flex-wrap">
//                       <button className="btn_in_house_job">In House</button>
//                       <button className="btn_in_house_job">
//                         <CiLocationOn />
//                         New York
//                       </button>
//                       <button className="btn_in_house_job">
//                         <CiDollar />
//                         45k-60k Yearly
//                       </button>
//                     </div>
//                   </div>
//                   <div className="col-lg-4 col-md-3 col-sm-12 col-12">
//                     <button className="apply_now_btn_job">apply Now</button>
//                   </div>
//                 </div>
//               </div>
//             </div>


//             <div className="col-lg-6 col-md-6 col-sm-12 col-12">
//               <div className="main_div_job_open_card">
//                 <div className="row p-0 m-0">
//                   <div className="col-lg-8 col-md-9 col-sm-12 col-12">
//                     <p className="heading_position_name">
//                       Senior UI/UX Designer
//                     </p>
//                     <div className="d-flex flex-row">
//                       <p className="by_grey_job_desp">By </p>
//                       <p className="black_para_job_desp">Spotify</p>
//                       <p className="by_grey_job_desp">in</p>
//                       <p className="by_orange_job_desp">Design & Creative</p>
//                     </div>

//                     <div className="d-flex flex-wrap">
//                       <button className="btn_in_house_job">In House</button>
//                       <button className="btn_in_house_job">
//                         <CiLocationOn />
//                         New York
//                       </button>
//                       <button className="btn_in_house_job">
//                         <CiDollar />
//                         45k-60k Yearly
//                       </button>
//                     </div>
//                   </div>
//                   <div className="col-lg-4 col-md-3 col-sm-12 col-12">
//                     <button className="apply_now_btn_job">apply Now</button>
//                   </div>
//                 </div>
//               </div>
//             </div>


//             <div className="col-lg-6 col-md-6 col-sm-12 col-12">
//               <div className="main_div_job_open_card">
//                 <div className="row p-0 m-0">
//                   <div className="col-lg-8 col-md-9 col-sm-12 col-12">
//                     <p className="heading_position_name">
//                       Senior UI/UX Designer
//                     </p>
//                     <div className="d-flex flex-row">
//                       <p className="by_grey_job_desp">By </p>
//                       <p className="black_para_job_desp">Spotify</p>
//                       <p className="by_grey_job_desp">in</p>
//                       <p className="by_orange_job_desp">Design & Creative</p>
//                     </div>

//                     <div className="d-flex flex-wrap">
//                       <button className="btn_in_house_job">In House</button>
//                       <button className="btn_in_house_job">
//                         <CiLocationOn />
//                         New York
//                       </button>
//                       <button className="btn_in_house_job">
//                         <CiDollar />
//                         45k-60k Yearly
//                       </button>
//                     </div>
//                   </div>
//                   <div className="col-lg-4 col-md-3 col-sm-12 col-12">
//                     <button className="apply_now_btn_job">apply Now</button>
//                   </div>
//                 </div>
//               </div>
//             </div>



//             <div className="col-lg-6 col-md-6 col-sm-12 col-12">
//               <div className="main_div_job_open_card">
//                 <div className="row p-0 m-0">
//                   <div className="col-lg-8 col-md-9 col-sm-12 col-12">
//                     <p className="heading_position_name">
//                       Senior UI/UX Designer
//                     </p>
//                     <div className="d-flex flex-row">
//                       <p className="by_grey_job_desp">By </p>
//                       <p className="black_para_job_desp">Spotify</p>
//                       <p className="by_grey_job_desp">in</p>
//                       <p className="by_orange_job_desp">Design & Creative</p>
//                     </div>

//                     <div className="d-flex flex-wrap">
//                       <button className="btn_in_house_job">In House</button>
//                       <button className="btn_in_house_job">
//                         <CiLocationOn />
//                         New York
//                       </button>
//                       <button className="btn_in_house_job">
//                         <CiDollar />
//                         45k-60k Yearly
//                       </button>
//                     </div>
//                   </div>
//                   <div className="col-lg-4 col-md-3 col-sm-12 col-12">
//                     <button className="apply_now_btn_job">apply Now</button>
//                   </div>
//                 </div>
//               </div>
//             </div>



//             <div className="col-lg-6 col-md-6 col-sm-12 col-12">
//               <div className="main_div_job_open_card">
//                 <div className="row p-0 m-0">
//                   <div className="col-lg-8 col-md-9 col-sm-12 col-12">
//                     <p className="heading_position_name">
//                       Senior UI/UX Designer
//                     </p>
//                     <div className="d-flex flex-row">
//                       <p className="by_grey_job_desp">By </p>
//                       <p className="black_para_job_desp">Spotify</p>
//                       <p className="by_grey_job_desp">in</p>
//                       <p className="by_orange_job_desp">Design & Creative</p>
//                     </div>

//                     <div className="d-flex flex-wrap">
//                       <button className="btn_in_house_job">In House</button>
//                       <button className="btn_in_house_job">
//                         <CiLocationOn />
//                         New York
//                       </button>
//                       <button className="btn_in_house_job">
//                         <CiDollar />
//                         45k-60k Yearly
//                       </button>
//                     </div>
//                   </div>
//                   <div className="col-lg-4 col-md-3 col-sm-12 col-12">
//                     <button className="apply_now_btn_job">apply Now</button>
//                   </div>
//                 </div>
//               </div>
//             </div>

           

           
//           </div>
//         </div>
//         <div className="col-lg-2 col-md-1 col-sm-12 col-12"></div>
//       </div>
//     </div>
//   );
// }



// export default NewJobOpenings;
// import React, { useEffect, useState } from "react";
// import "./../NewJobOpenings/NewJobOpenings.css";
// import { CiLocationOn } from "react-icons/ci";
// import { CiDollar } from "react-icons/ci";
// import { useNavigate } from "react-router-dom";

// function NewJobOpenings() {
//   const navigate = useNavigate();
//   const [jobs, setJobs] = useState([]); // State to hold job data
//   const [loading, setLoading] = useState(true); // State to handle loading state

//   // Fetch job data from the API
//   useEffect(() => {
//     const fetchJobs = async () => {
//       try {
//         const response = await fetch("http://localhost:8000/api/jobs");
//         if (!response.ok) {
//           throw new Error("Network response was not ok");
//         }
//         const data = await response.json();
//         setJobs(data); // Set the job data to state
//       } catch (error) {
//         console.error("Failed to fetch jobs:", error);
//       } finally {
//         setLoading(false); // Set loading to false after fetching
//       }
//     };

//     fetchJobs();
//   }, []);

//   const jobDescription = () => {
//     navigate("/job/description");
    
//   }

//   return (
//     <div className="main_div_newjobopenings">
//       <p className="new_opening_para">New Openings</p>
//       <p className="new_opening_heading">Explore Popular Jobs</p>
//       <div className="d-flex justify-content-center">
//         <div className="new_opening_div_hr"></div>
//       </div>

//       {loading ? ( // Show loading state
//         <p>Loading jobs...</p>
//       ) : (
//         <div className="row m-0 p-0">
//           <div className="col-lg-2 col-md-1 col-sm-12 col-12"></div>
//           <div className="col-lg-8 col-md-10 col-sm-12 col-12">
//             <div className="row">
//               {jobs.map((job) => ( // Map through jobs
//                 <div className="col-lg-6 col-md-6 col-sm-12 col-12" key={job.id}>
//                   <div className="main_div_job_open_card">
//                     <div className="row p-0 m-0">
//                       <div className="col-lg-8 col-md-9 col-sm-12 col-12">
//                         <p className="heading_position_name">{job.title}</p>
//                         <div className="d-flex flex-row">
//                           <p className="by_grey_job_desp">By </p>
//                           <p className="black_para_job_desp">{job.company}</p>
//                           <p className="by_grey_job_desp">in</p>
//                           <p className="by_orange_job_desp">{job.category}</p>
//                         </div>
//                         <div className="d-flex flex-wrap">
//                           <button className="btn_in_house_job">{job.type}</button>
//                           <button className="btn_in_house_job">
//                             <CiLocationOn />
//                             {job.location}
//                           </button>
//                           <button className="btn_in_house_job">
//                             <CiDollar />
//                             {job.salary}
//                           </button>
//                         </div>
//                       </div>
//                       <div className="col-lg-4 col-md-3 col-sm-12 col-12">
//                         <button className="apply_now_btn_job" onClick={jobDescription}>apply Now</button>
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               ))}
//             </div>
//           </div>
//           <div className="col-lg-2 col-md-1 col-sm-12 col-12"></div>
//         </div>
//       )}
//     </div>
//   );
// }

// export default NewJobOpenings;


import React, { useEffect, useState } from "react";
import "./../NewJobOpenings/NewJobOpenings.css";
import { CiLocationOn, CiDollar } from "react-icons/ci";
import { useNavigate } from "react-router-dom";

function NewJobOpenings() {
  const navigate = useNavigate();
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchJobs = async () => {
      try {
        const response = await fetch("http://localhost:8000/api/jobs");
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        const data = await response.json();
        setJobs(data);
      } catch (error) {
        console.error("Failed to fetch jobs:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, []);

  // Update the jobDescription function to pass only the job ID
  const jobDescription = (jobId) => {
    navigate("/job/description", { state: { jobId } }); // Pass the job ID to the description page
  };

  return (
    <div className="main_div_newjobopenings">
      <p className="new_opening_para">New Openings</p>
      <p className="new_opening_heading">Explore Popular Jobs</p>
      <div className="d-flex justify-content-center">
        <div className="new_opening_div_hr"></div>
      </div>

      {loading ? (
        <p>Loading jobs...</p>
      ) : (
        <div className="row m-0 p-0">
          <div className="col-lg-2 col-md-1 col-sm-12 col-12"></div>
          <div className="col-lg-8 col-md-10 col-sm-12 col-12">
            <div className="row">
              {jobs.map((job) => (
                <div className="col-lg-6 col-md-6 col-sm-12 col-12" key={job.id}>
                  <div className="main_div_job_open_card">
                    <div className="row p-0 m-0">
                      <div className="col-lg-8 col-md-9 col-sm-12 col-12">
                        <p className="heading_position_name">{job.title}</p>
                        <div className="d-flex flex-row">
                          <p className="by_grey_job_desp">By </p>
                          <p className="black_para_job_desp">{job.company}</p>
                          <p className="by_grey_job_desp">in</p>
                          <p className="by_orange_job_desp">{job.category}</p>
                        </div>
                        <div className="d-flex flex-wrap">
                          <button className="btn_in_house_job">{job.mode}</button>
                          <button className="btn_in_house_job">
                            <CiLocationOn />
                            {job.location}
                          </button>
                          <button className="btn_in_house_job">
                            <CiDollar />
                            {job.salary}
                          </button>
                        </div>
                      </div>
                      <div className="col-lg-4 col-md-3 col-sm-12 col-12">
                        <button className="apply_now_btn_job" onClick={() => jobDescription(job.id)}>Apply Now</button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="col-lg-2 col-md-1 col-sm-12 col-12"></div>
        </div>
      )}
    </div>
  );
}

export default NewJobOpenings;


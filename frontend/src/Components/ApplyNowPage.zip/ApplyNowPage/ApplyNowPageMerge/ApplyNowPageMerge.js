import React, { useEffect, useRef, useState } from "react";
import Footer from "../../Homepage/Footer/Footer";
import FooterAll from "../../Homepage/FooterAll/FooterAll";
import Navbarsynergtech from "../../Homepage/Navbarsynergtech/Navbarsynergtech";
import EventGallery from "../../AboutusPage/EventGallery/EventGallery";
import ApplynowNavbar from "../ApplynowNavbar/ApplynowNavbar";
import Banner1 from "../../Homepage/Banner1/Banner1";
import SolutionServices from "../../Homepage/SolutionServices/SolutionServices";
import Customers from "../../Homepage/Customers/Customers";
import NewJobOpenings from "../NewJobOpenings/NewJobOpenings";

import synergy from "./../../../Assets/synergy-logo-3 1.png";
import clock from "./../../../Assets/clock_syn.png";
import phone from "./../../../Assets/phone_syn.png";
import {
  FaFacebook,
  FaTwitter,
  FaInstagram,
  FaLinkedin,
  FaYoutube,
} from "react-icons/fa";
import { Link } from "react-router-dom";
import { IoReorderThreeOutline } from "react-icons/io5";
import Appointment from "../../Homepage/Appointment/Appointment";

function ApplyNowPageMerge() {
  const appointmentRef = useRef(null);

  const scrollToAppointment = () => {
    if (appointmentRef.current) {
      appointmentRef.current.scrollIntoView({ behavior: "smooth" });
    }
  };
  const [isVisible, setIsVisible] = useState(false);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  };

  useEffect(() => {
    const toggleVisibility = () => {
      if (window.pageYOffset > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }
    };

    window.addEventListener("scroll", toggleVisibility);
    scrollToTop();
    return () => {
      window.removeEventListener("scroll", toggleVisibility);
    };
  }, []);
  return (
    <div>
      <>
        {isVisible && (
          <button onClick={scrollToTop} className="scroll-to-top-button">
            <span>&uarr;</span>
          </button>
        )}
      </>
      {/* <Navbarsynergtech /> */}

      <>
        <div className="main_div_sticky">
          <>
            <div className="uppernavbar">
              <div className="inside_div_navbar">
                <div className="d-flex justify-content-between content-wrapper">
                  <div className="d-flex flex-row">
                    <div className="d-flex flex-row">
                      <img
                        src={clock}
                        className="clock_style_syn"
                        alt="clock"
                      />
                      <p className="clock_para_syn">
                        Mon - Fri: 09.00am - 10.00 pm
                      </p>
                    </div>
                    <div className="d-flex flex-row main_div_clock">
                      <img
                        src={clock}
                        className="clock_style_syn"
                        alt="clock"
                      />
                      <p className="clock_para_syn">
                        Richardson, California 62639
                      </p>
                    </div>
                    <div className="d-flex flex-row main_div_clock">
                      <img
                        src={clock}
                        className="clock_style_syn"
                        alt="clock"
                      />
                      <p className="clock_para_syn">TANGO@mail.com</p>
                    </div>
                  </div>

                  <div className="transform_second_div">
                    <div className="d-flex flex-row">
                      <div className="d-flex flex-row">
                        <img
                          src={phone}
                          className="phone_style_syn"
                          alt="phone"
                        />
                        <p className="clock_para_syn">Make a Call</p>
                        <p className="phone_p7ara_syn_bold">+36 55 540 069</p>
                        <div className="social-media-row">
                          <a
                            href="https://www.facebook.com"
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <FaFacebook className="social-icon" />
                          </a>
                          <a
                            href="https://www.twitter.com"
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <FaTwitter className="social-icon" />
                          </a>
                          <a
                            href="https://www.instagram.com"
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <FaInstagram className="social-icon" />
                          </a>
                          <a
                            href="https://www.linkedin.com"
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <FaLinkedin className="social-icon" />
                          </a>
                          <a
                            href="https://www.youtube.com"
                            target="_blank"
                            rel="noopener noreferrer"
                          >
                            <FaYoutube className="social-icon" />
                          </a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </>
          <nav class="navbar navbar-expand-lg p-0 m-0">
            <a class="navbar-brand">
              <Link to="/">
                <img src={synergy} className="synergytech_logo" />
              </Link>
            </a>
            <button
              class="navbar-toggler"
              type="button"
              data-toggle="collapse"
              data-target="#navbarSupportedContent"
              aria-controls="navbarSupportedContent"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <IoReorderThreeOutline />
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                  <Link to="/">
                    <p class="navitems_synergytechnavbar1">HOME </p>
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/aboutus">
                    <p class="navitems_synergytechnavbar">ABOUS US</p>
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/blogs">
                    <p class="navitems_synergytechnavbar">BLOGS </p>
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/applynow">
                    <p class="navitems_synergytechnavbar">APPLY NOW</p>
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/team">
                    <p class="navitems_synergytechnavbar">TEAM </p>
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/portfolio">
                    <p class="navitems_synergytechnavbar">PORTFOLIO </p>
                  </Link>
                </li>
                <li class="nav-item">
                  <Link to="/case/studies">
                    <p class="navitems_synergytechnavbar">CASE STUDY</p>
                  </Link>
                </li>
              </ul>
              <form class="form-inline">
                <button
                  className="btn_request_quote"
                  type="button"
                  onClick={scrollToAppointment}
                >
                  REQUEST A QUOTE
                </button>
              </form>
            </div>
          </nav>
        </div>
      </>
      <ApplynowNavbar />
      <NewJobOpenings />
      <Banner1 />
      <SolutionServices />
      <EventGallery />
      <div ref={appointmentRef}>
        <Appointment />
      </div>
      <Customers />
      <FooterAll />
      <Footer />
    </div>
  );
}

export default ApplyNowPageMerge;
